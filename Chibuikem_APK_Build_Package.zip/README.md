# Chibuikem Android app

A starter Android Studio project for a toddler learning app (ages 1–3). The lessons and games are bundled locally, so the learning screens do not require an internet connection.

## Included
- Animal words, colours, counting, shapes, first letters and first words
- Large touch targets and simple toddler-friendly navigation
- British English Android text-to-speech request (`Locale.UK`)
- A simple picture-finding game\n- On-device learning progress (lesson views, quiz answers and topics explored)\n- Parent area protected by a simple adult maths check\n- Parent dashboard with a local progress summary and reset option
- Offline HTML learning content packaged inside the Android app

## Build an APK
1. Install Android Studio on a computer.
2. Open this `ChibuikemAndroid` folder in Android Studio.
3. Allow Gradle to sync. Use JDK 17 if Android Studio asks.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer the APK to the Android phone and install it. The phone may ask you to allow installation from that file manager.

## Voice and offline notes
The app asks Android TextToSpeech to use British English (`en-GB`). Actual voice availability depends on the phone's installed TTS engine and downloaded voice data. If British English voice data is not installed, install it in Android Settings > Text-to-speech output / Speech Services voice data. Some devices may need internet once to download that voice. The app's lessons themselves work offline.

## Before public release
This is an enhanced starter project, not a store-ready release. The parent-area maths check is a basic barrier, not a secure parental-control system. Before public release, replace emoji placeholders with reviewed real-photo and cartoon assets, add recorded animal sounds and a stronger parent gate, provide a privacy policy, complete accessibility testing, and meet applicable child-privacy requirements. An adult should supervise use.


## Build an APK using GitHub Actions

This project includes `.github/workflows/android-apk.yml`.

1. Create a GitHub repository and upload the contents of this project (including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Chibuikem APK** and choose **Run workflow** (or push to `main`/`master`).
4. When the workflow completes successfully, open its run and download the `Chibuikem-debug-apk` artifact.
5. Extract the downloaded artifact to get `app-debug.apk`. Transfer it to your Android phone and install it. You may need to allow installation from that file manager.

The workflow builds a debug APK for testing. It is not a Play Store release-signed APK. The build has not been run or verified from this environment.
